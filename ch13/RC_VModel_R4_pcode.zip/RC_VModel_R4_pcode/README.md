# V-Model Lab — Arduino UNO R4 WiFi (MIL · SIL · PIL · HIL) — v2: RC + TCLab — **P-code edition**
01068007 Control Systems · I&C Engineering, KMITL

This package has the same features as the `RC_VModel_R4` source edition, but every MATLAB file is **P-code (`.p`)**,
and the firmware is a compiled binary (`.bin`),
so students can run it but cannot open or edit the source. **It needs MATLAB R2022a or later** (the P-code was built with R2026a).

| Folder | File | Purpose |
|---|---|---|
| `matlab/` | **`RC_VModelApp.p`** | The app (6 tabs: ⓪ Plant & ID, ① MIL, ② SIL, ③ PIL, ④ HIL, ⑤ Compare), started with `RC_VModelApp` |
| | `rc_params.p`, `rc_pi_step.p` (UUT), `rc_design_pi.p` | Parameters, PI controller, PI design |
| | `rc_plant.p`, `rc_zoh_init.p`, `rc_zoh_step.p`, `rc_io_quant.p`, `rc_quant.p` | Plant models and converter quantisation |
| | `rc_sim_mil.p`, `rc_sim_sil.p`, `rc_pil_run.p`, `rc_hil_run.p` | Harnesses for the 4 stages |
| | `rc_fit_fopdt.p`, `rc_fit_eb.p` | Identification from a step test |
| | `rc_connect.p`, `rc_send_config.p`, `rc_metrics.p`, `rc_ref.p` | Helper functions |
| | `rc_flash_firmware.p` | Upload the firmware from MATLAB: `rc_flash_firmware('COM5')` |
| `dev/` | `rc_mock_target.p` | Simulated board for testing PIL/HIL without hardware |
| `firmware/` | `rc_vmodel_r4_v2.bin` | Compiled firmware v2 (63,512 bytes, `arduino:renesas_uno:unor4wifi`, core 1.6.0) |
| | `rc_vmodel_r4_v2.bin.sha256` | Checksum for checking the file |
| | `flash_r4.bat` | Upload without MATLAB: `flash_r4.bat COM5` |
| `docs/` | `rc_vmodel_handout.pdf`, `rc_vmodel_slides.pdf` | Handout and slides |

## Upload the firmware (once per board)
Install **"Arduino UNO R4 Boards"** once in the Arduino IDE Boards Manager (this supplies `bossac`), then close every program that uses the serial port, and use either method:
```matlab
cd matlab
rc_flash_firmware('COM5')        % 1200-baud touch -> bossac -e -w -R, the same steps as the Arduino IDE
```
or, in Command Prompt, run `firmware\flash_r4.bat COM5` (it uses arduino-cli if available, otherwise bossac).
If the upload fails, press **RESET twice quickly** (the LED fades in and out) and try again.
After uploading, Connect in the app must show `READY,VMODEL-R4,v2`.

## Usage
```matlab
cd matlab
RC_VModelApp                                   % open the app
% or from the Command Window (no GUI):
P = rc_params();            R = rc_sim_sil(P);
addpath ../dev;  s = rc_mock_target;  R = rc_pil_run(s, P);   % PIL without a board
```
**RC:** connect the circuit (remove the TCLab shield first) → upload the firmware (above) → Plant = RC → Connect → MIL → SIL → PIL → HIL
**TCLab:** fit the shield → Plant = TCLab → Connect → tab ⓪ Read T1/T2 → Step test → Fit FOPDT → Fit energy balance → MIL → SIL → PIL → HIL

> ⚠ A0 is both the DAC for RC and the T1 sensor for TCLab. Never fit both at once (see the handout, TCLab section).

## Notes on P-code
- `help`/`doc` does not work for P-code files (P-code does not keep comments). Read the descriptions in the handout instead.
- There is no `.mlapp` file in this package because App Designer can open it and show its code. The app runs from `RC_VModelApp.p`, which behaves exactly like the original.
- Verified on R2026a Update 5 with only the P-code folders on the path: MIL tr = 1.099 s, SIL tr = 1.080 s, PIL (mock) max|Δu| = 1.221 mV = 1 LSB, TCLab MIL/SIL tr = 69.8/69.0 s; the app opens with all 6 tabs, and Run MIL and Run SIL work.
