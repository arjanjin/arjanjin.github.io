@echo off
REM ==========================================================================
REM  flash_r4.bat  -  upload rc_vmodel_r4_v2.bin to an Arduino UNO R4 WiFi
REM  Usage:  flash_r4.bat COM5
REM  Needs the "Arduino UNO R4 Boards" core installed once in the Arduino IDE.
REM  Close RC_VModelApp / Serial Monitor first.
REM ==========================================================================
setlocal
if "%~1"=="" (
  echo Usage: flash_r4.bat COMx   ^(e.g. flash_r4.bat COM5^)
  echo Find the port in Device Manager or in the Arduino IDE ^(Tools ^> Port^).
  exit /b 1
)
set PORT=%~1
set BIN=%~dp0rc_vmodel_r4_v2.bin
if not exist "%BIN%" ( echo Firmware file not found: %BIN% & exit /b 1 )

REM ---- 1) arduino-cli (on PATH or bundled with Arduino IDE 2) ----
set CLI=
where arduino-cli >nul 2>&1 && set CLI=arduino-cli
if "%CLI%"=="" if exist "%LOCALAPPDATA%\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe" set CLI="%LOCALAPPDATA%\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
if "%CLI%"=="" if exist "%ProgramFiles%\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe" set CLI="%ProgramFiles%\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
if not "%CLI%"=="" (
  echo Using arduino-cli ...
  %CLI% upload -b arduino:renesas_uno:unor4wifi -p %PORT% --input-file "%BIN%"
  if not errorlevel 1 goto ok
  echo arduino-cli failed, trying bossac ...
)

REM ---- 2) bossac directly (1200-baud touch via PowerShell) ----
set BOSSAC=
for /d %%D in ("%LOCALAPPDATA%\Arduino15\packages\arduino\tools\bossac\*") do if exist "%%D\bossac.exe" set BOSSAC="%%D\bossac.exe"
if "%BOSSAC%"=="" ( echo bossac not found: install "Arduino UNO R4 Boards" in the Arduino IDE Boards Manager & exit /b 1 )
powershell -NoProfile -Command "$p=New-Object System.IO.Ports.SerialPort '%PORT%',1200; $p.Open(); Start-Sleep -m 200; $p.Close()" 2>nul
timeout /t 2 /nobreak >nul
%BOSSAC% -d --port=%PORT% -U -e -w "%BIN%" -R
if errorlevel 1 ( echo Upload failed. Press RESET twice quickly, then run this again. & exit /b 1 )

:ok
echo.
echo Upload complete. Wait about 3 s, then press Connect in RC_VModelApp (banner READY,VMODEL-R4,v2).
endlocal
